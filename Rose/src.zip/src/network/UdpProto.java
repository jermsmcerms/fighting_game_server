package network;

import java.net.SocketAddress;
import java.util.Arrays;
import java.util.LinkedList;

import library.GameInput;
import library.IPollSink;
import library.Poll;
import library.RingBuffer;
import network.UdpMsg.MsgType;
import server.Server;

public class UdpProto implements IPollSink {
    private static final int NUM_SYNC_PACKETS = 5;
	private static final int MAX_SEQ_DISTANCE = 32768;
    private static int playerNumber = 1;
    private static int numConnections = 0;
    private int next_send_seq;
    private RingBuffer<QueueEntry> send_queue;
    private RingBuffer<UdpProtocolEvent> event_queue;
    private RingBuffer<GameInput> pending_output;
    private LinkedList<GameInput> input_queue;
    private SocketAddress client_addr;
    private Udp udp;
    private int disconnect_timeout;
    private int disconnect_notify_start;
    private State state;
    private ConnectState current_state;
    private boolean isInitialized;
	private int next_recv_seq;
    
	public UdpProto() {
		isInitialized = false;
	}
    
    public void init(Udp udp, Poll poll, SocketAddress client_addr, 
    		int portNum, int disconnect_timeout, int disconnect_notify_start,
    		UdpMsg msg) {
    	this.udp = udp;
        this.disconnect_timeout = disconnect_timeout;
        this.disconnect_notify_start = disconnect_notify_start;
        this.client_addr = client_addr;
        send_queue = new RingBuffer<>(64);
        event_queue = new RingBuffer<>(64);
        pending_output = new RingBuffer<>(128);
        input_queue = new LinkedList<>();
        
        next_send_seq = 0;
        poll.registerLoop(this);

        state = new State();
        
        if(udp != null) {
        	current_state = ConnectState.Syncing;
        	state.sync.round_trips_remaining = NUM_SYNC_PACKETS;
        	onConnectReq(msg);
        }
        
		numConnections++;
        isInitialized = true;
    }

	private void sendMsg(UdpMsg msg) {
		msg.hdr.sequenceNumber = next_send_seq++;
		send_queue.push(new QueueEntry(System.nanoTime(), client_addr, msg));
		pumpSendQueue();
	}

	private void pumpSendQueue() {
		while(!send_queue.empty()) {
			QueueEntry entry = send_queue.front();
			udp.sendTo(entry.msg, entry.dest_addr);
			send_queue.pop();
		}
	}

	public boolean getIsInitialized() { return isInitialized; }

	public boolean handlesMsg(SocketAddress from) {
		if(udp == null) return false;
		return from.equals(client_addr);
	}

	public void onMsg(UdpMsg msg, int queue) {
		boolean handled = false;
		switch(msg.hdr.type) {
		case 0:
			onInvalid(msg);
			break;
		case 1:
			handled = onConnectReq(msg);
			break;
		case 2:
			handled = onConnectRep(msg);
			break;
        case 3:
            handled = onStartReq(msg);
            break;
        case 4:
            handled = onStartRep(msg);
            break;
        case 5:
            handled = onInput(msg);
            break;
		}
		
		int seq = msg.hdr.sequenceNumber;
		if(	msg.hdr.type != MsgType.ConnectReq.ordinal() && 
			msg.hdr.type != MsgType.ConnectReply.ordinal()) {
			// TODO: reject messages from senders we don't expect
		}
		
		int skipped = seq - next_recv_seq;
		if(skipped > MAX_SEQ_DISTANCE) {
			return;
		}
		
		next_recv_seq = seq;
		if(msg.hdr.type < 0 || msg.hdr.type > 3) {
			onInvalid(msg);
		}
		
		if(handled) {
			// TODO: handle network resumed events
			//		 if a disconnect notification has been sent and
			//		 if the current state is running
		}
	}

	private void onInvalid(UdpMsg msg) {
		// TODO Auto-generated method stub
		
	}

	private boolean onConnectReq(UdpMsg msg) {
		// TODO: make sure we only handle requests form sources we expect
		UdpMsg reply = new UdpMsg(MsgType.ConnectReply);
//		System.out.println(Arrays.toString(msg.getData()));
		reply.payload.connRep.random_reply = msg.payload.connReq.random_request;
		reply.payload.connRep.playerNumber = playerNumber++;
		sendMsg(reply);
		return true;
	}
	
	private boolean onConnectRep(UdpMsg msg) {
		// TODO Auto-generated method stub
		return false;
	}

	private boolean onStartReq(UdpMsg msg) {
		UdpMsg reply = new UdpMsg(MsgType.StartRep);
		if(numConnections == Server.NUM_PLAYERS) {
			reply.payload.startRep.response = 1;
		} else {
			reply.payload.startRep.response  = 0;
		}
		
		sendMsg(reply);
        return true;
    }

    private boolean onStartRep(UdpMsg msg) {
        return true;
    }
    
	private boolean onInput(UdpMsg msg) {
		GameInput input = new GameInput();
		input.frame = msg.payload.input.frame;
		input.input = msg.payload.input.input;
		input_queue.add(input);
		return true;
	}

	public SocketAddress getAddress() {
		return client_addr;
	}

	public UdpProtocolEvent getEvent() {
		if(event_queue.size() == 0) { return null; }
		UdpProtocolEvent event = event_queue.front();
		event_queue.pop();
		return event;
	}

	public GameInput getInput() {
		if(input_queue == null || input_queue.isEmpty()) { return null; }
		return input_queue.pop();
	}

	public void sendInput(GameInput input, SocketAddress dst) {
		if(udp != null) {
			UdpMsg msg = new UdpMsg(UdpMsg.MsgType.Input);
			msg.payload.input.frame = input.frame;
			msg.payload.input.input = input.input;
			udp.sendTo(msg, dst);
		}
	}
}

class QueueEntry {
    public long queue_time;
    public SocketAddress dest_addr;
    UdpMsg msg;

    public QueueEntry(long queue_time, SocketAddress in_addr, UdpMsg msg) {
        this.queue_time = queue_time;
        this.dest_addr = in_addr;
        this.msg = msg;
    }
}

class State {
    public Sync sync;

    public State() {
        sync = new Sync();
    }

    public class Sync {
        public int round_trips_remaining;
        public int random;
    }
    // TODO: create a state for running
}

enum ConnectState {
    Syncing, Synchronized, Running, Disconnected
}
