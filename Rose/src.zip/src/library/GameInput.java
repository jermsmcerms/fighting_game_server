package library;

public class GameInput {
	public int frame;
	public int input;
}
